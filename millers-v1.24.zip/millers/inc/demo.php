<?php

function millers_import_files() {
    return [
        [
            'import_file_name'           => 'BlogZine Millers Demo 1',
            'import_file_url'            => get_template_directory_uri() . '/inc/demo/blogzine-content.xml',
            'import_preview_image_url'   => get_template_directory_uri() . '/inc/demo/preview.jpg',
            // 'import_widget_file_url'     => get_template_directory_uri() . '/inc/demo/blogzine-widgets.wie',
            'import_customizer_file_url' => get_template_directory_uri() . '/inc/demo/blogzine-customizer.dat',
            'preview_url'                => 'https://blogzine.wpskilla.com/',
        ]
    ];
}
add_filter('pt-ocdi/import_files', 'millers_import_files');


function millers_after_import_setup() {
    // Set home and blog pages
    $home = get_page_by_title('Home BlogZine');
    $blog = get_page_by_title('Blog BlogZine');
    
    if ($home) {
        update_option('page_on_front', $home->ID);
        update_option('show_on_front', 'page');
    }
    
    if ($blog) {
        update_option('page_for_posts', $blog->ID);
    }

    // Assign menus
    $menu = get_term_by('name', 'Main Menu BlogZine', 'nav_menu');
    if ($menu) {
        set_theme_mod('nav_menu_locations', ['primary' => $menu->term_id]);
    }
}
add_action('ocdi/after_import', 'millers_after_import_setup');




