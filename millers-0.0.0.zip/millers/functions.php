<?php

// Theme setup
function millers_theme_setup() {

    // ==========================
    // default code
    // ==========================

    include_once(ABSPATH . 'wp-admin/includes/plugin.php');

    // theme supports
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');

    // menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'my-starter-theme'),
    ]);

    // remove actions
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );

    // head action
    function preload_images() {
        echo '<link rel="preload" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZWVlZWVlIiAvPjwvc3ZnPg==" as="image" type="image/svg+xml">';
    }
    add_action('wp_head', 'preload_images');

    // wp enqueue scripts and styles
    function theme_enqueue_scripts_func() {
        if (!is_admin()) {
            // enqueue styles
            wp_enqueue_style('forms-starter-styles', get_template_directory_uri() . '/assets/plugin/forms/forms-starter-styles.css', array(), null, 'all');
            // dequeue default js
            wp_dequeue_script('jquery');
            wp_deregister_script('jquery');
            wp_dequeue_script('jquery-migrate');
            wp_deregister_script('jquery-migrate');
            // enqueue js
            wp_register_script('jquery', includes_url('/js/jquery/jquery.min.js'), [], '3.7.1', true);
            wp_register_script('jquery-migrate', includes_url('/js/jquery/jquery-migrate.min.js'), ['jquery'], '3.4.1', true);
            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-migrate');
        }
    }
    add_action('wp_enqueue_scripts', 'theme_enqueue_scripts_func', 11);

    // forced removing styles
    function force_remove_styles_func() {
        if (!is_admin()) {
            // Fluent Forms
            wp_dequeue_style('fluent-form-styles');
            wp_deregister_style('fluent-form-styles');
            wp_dequeue_style('fluentform-public-default');
            wp_deregister_style('fluentform-public-default');
            // Contact Form 7
            wp_dequeue_style('contact-form-7');
            wp_deregister_style('contact-form-7');
            // Formidable Forms
            wp_dequeue_style('formidable');
            wp_deregister_style('formidable');
            // Ninja Forms
            wp_dequeue_style('nf-display');
            wp_deregister_style('nf-display');
            // Forminator form
            if (is_plugin_active('forminator/forminator.php')) {
                wp_enqueue_style('forminator-all-styles', get_template_directory_uri() . '/assets/plugin/forminator/forminator-all-styles.css', array(), null, 'all');
            }
            // WooCommerce
            if (is_plugin_active('woocommerce/woocommerce.php')) {
                wp_dequeue_style('woocommerce-layout');
                wp_deregister_style('woocommerce-layout');
                wp_dequeue_style('woocommerce-smallscreen');
                wp_deregister_style('woocommerce-smallscreen');
                wp_dequeue_style('woocommerce-general');
                wp_deregister_style('woocommerce-general');
                wp_dequeue_style('brands-styles');
                wp_deregister_style('brands-styles');
                wp_enqueue_style('woocommerce-starter-styles', get_template_directory_uri() . '/assets/plugin/woocommerce/woocommerce-starter-styles.css', array(), null, 'all');
            }
            // Dashicons & Buttons
            if (!is_user_logged_in()) {
                wp_dequeue_style('dashicons');
                wp_deregister_style('dashicons');
                wp_dequeue_style('buttons');
                wp_deregister_style('buttons');
            }
            // Media Player
            wp_dequeue_style('mediaelement');
            wp_deregister_style('mediaelement');
            wp_dequeue_style('wp-mediaelement');
            wp_deregister_style('wp-mediaelement');
        }
    }
    add_action('wp_enqueue_scripts', 'force_remove_styles_func', 999);
	// forced removing styles v2
    function remove_forminator_inline_styles() {
        ob_start(); // Start output buffering
    }
    add_action('wp_head', 'remove_forminator_inline_styles', 1);
    add_action('wp_footer', 'remove_forminator_inline_styles', 1);
    function clean_forminator_styles() {
        $html = ob_get_clean(); // Get buffered output
        // Remove unwanted CSS files
        $patterns = [
            '/<link[^>]+forminator-icons-css[^>]+>/i',
            '/<link[^>]+forminator-utilities-css[^>]+>/i',
            '/<link[^>]+forminator-grid-default-css[^>]+>/i',
            '/<link[^>]+forminator-forms-default-base-css[^>]+>/i',
            '/<link[^>]+forminator-forms-default-select2-css[^>]+>/i',
            '/<link[^>]+intlTelInput-forminator-css-css[^>]+>/i'
        ];
        foreach ($patterns as $pattern) {
            $html = preg_replace($pattern, '', $html);
        }
        echo $html;
    }
    add_action('shutdown', 'clean_forminator_styles', 0);

    // ==========================
    // db optimizations
    // ==========================

    // remove revison post type
    // Completely remove revisions from all post types
    function disable_revisions_for_all_post_types() {
        foreach (get_post_types() as $post_type) { remove_post_type_support($post_type, 'revisions'); }
    }
    add_action('init', 'disable_revisions_for_all_post_types');
    // Prevent saving revisions by intercepting post data
    function prevent_revision_creation($data, $postarr) {
        if (isset($data['post_type']) && 'revision' === $data['post_type']) { return false; }
        return $data;
    }
    add_filter('wp_insert_post_data', 'prevent_revision_creation', 10, 2);
    // Clear existing revisions from the database (optional, for cleanup)
    function db_clean_on_save_post($post_id, $post, $update) {
        // Avoid infinite loops and ensure proper execution.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (wp_is_post_revision($post_id)) { return; }
        // Unregister the revision post type.
        global $wp_post_types;
        if (isset($wp_post_types['revision'])) { unset($wp_post_types['revision']); }
        // save post clean the db
        global $wpdb;
        $ids_to_delete = [];
        // Get all revision post IDs
        $db_clean_revisions = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision'");
        if (!empty($db_clean_revisions)) {
            $ids_to_delete = array_merge($ids_to_delete, array_column($db_clean_revisions, 'ID'));
        }
        // Get all 'customize_changeset' post IDs, excluding the newest 2
        $db_clean_customize_changeset = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'customize_changeset' ORDER BY post_date ASC");
        if (count($db_clean_customize_changeset) > 2) {
            $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_customize_changeset, 'ID'), 0, count($db_clean_customize_changeset) - 2));
        }
        // Get all 'auto-draft' post IDs, excluding the newest 2
        $db_clean_auto_draft = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' ORDER BY post_date ASC");
        if (count($db_clean_auto_draft) > 2) {
            $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_auto_draft, 'ID'), 0, count($db_clean_auto_draft) - 2));
        }
        // Delete all posts with the collected IDs
        if (!empty($ids_to_delete)) {
            foreach ($ids_to_delete as $post_id) {
                wp_delete_post($post_id, true);
            }
        }
        // List of unwanted meta keys
        // wp | [ _edit_lock, _edit_last, _encloseme ]
        // Smush | [ wp-smush-lossy ]
        // FakerPress | [ fakerpress_flag, _fakerpress_orginal_url ]
        $db_clean_meta_keys_arr = [
            '_edit_lock',
            '_edit_last',
            '_encloseme',
            'wp-smush-lossy',
            'fakerpress_flag',
            '_fakerpress_orginal_url',
        ];
        // Delete unwanted post meta keys
        foreach ($db_clean_meta_keys_arr as $meta_key) {
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s",
                    $meta_key
                )
            );
        }
    }
    add_action('save_post', 'db_clean_on_save_post', 10, 3);

    // post meta table optimizations
    function force_remove_unwanted_post_meta_keys( $null, $object_id, $meta_key, $meta_value, $unique ) {
        // List of unwanted meta keys
        // wp | [ _edit_lock, _edit_last ]
        // Smush | [ wp-smush-lossy ]
        $unwanted_meta_keys = [
            'wp-smush-lossy',       // Smush lossy meta
            '_edit_lock',           // Post edit lock
            '_edit_last'            // Last edited user
        ];
        // Check if the current meta key is in the unwanted list
        if ( in_array( $meta_key, $unwanted_meta_keys, true ) ) {
            return true; // Returning true prevents the meta from being added
        }
        return $null;
    }
    add_filter( 'add_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );
    add_filter( 'update_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );
    add_filter( 'delete_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );

}
add_action('after_setup_theme', 'millers_theme_setup');




