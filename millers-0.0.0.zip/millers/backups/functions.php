<?php

// Theme setup
function millers_theme_setup() {

    // ==========================
    // default code
    // ==========================

    // theme supports
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');

    // menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'my-starter-theme'),
    ]);

    // remove actions
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );

    // head action
    function preload_images() {
        echo '<link rel="preload" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZWVlZWVlIiAvPjwvc3ZnPg==" as="image" type="image/svg+xml">';
    }
    add_action('wp_head', 'preload_images');

    // wp enqueue scripts and styles
    function theme_enqueue_scripts_func() {
        if (!is_admin()) {
            // enqueue styles
            wp_enqueue_style('forms-starter-styles', get_template_directory_uri() . '/assets/plugin/forms/forms-starter-styles.css', array(), null, 'all');
            wp_enqueue_style('woocommerce-starter-styles', get_template_directory_uri() . '/assets/plugin/woocommerce/woocommerce-starter-styles.css', array(), null, 'all');
            // dequeue default js
            wp_dequeue_script('jquery');
            wp_deregister_script('jquery');
            wp_dequeue_script('jquery-migrate');
            wp_deregister_script('jquery-migrate');
            // enqueue js
            wp_register_script('jquery', includes_url('/js/jquery/jquery.min.js'), [], '3.7.1', true);
            wp_register_script('jquery-migrate', includes_url('/js/jquery/jquery-migrate.min.js'), ['jquery'], '3.4.1', true);
            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-migrate');
        }
    }
    add_action('wp_enqueue_scripts', 'theme_enqueue_scripts_func', 11);

    // forced removing styles
    function force_remove_styles_func() {
        global $wp_styles;
        // fluent-form
        if (isset($wp_styles->registered['fluent-form-styles'])) { unset($wp_styles->registered['fluent-form-styles']); }
        if (isset($wp_styles->registered['fluentform-public-default'])) { unset($wp_styles->registered['fluentform-public-default']); }
        // woocommerce
        if (isset($wp_styles->registered['woocommerce-layout'])) { unset($wp_styles->registered['woocommerce-layout']); }
        if (isset($wp_styles->registered['woocommerce-smallscreen'])) { unset($wp_styles->registered['woocommerce-smallscreen']); }
        if (isset($wp_styles->registered['woocommerce-general'])) { unset($wp_styles->registered['woocommerce-general']); }
        if (isset($wp_styles->registered['brands-styles'])) { unset($wp_styles->registered['brands-styles']); }
        // contact-form-7
        if (isset($wp_styles->registered['contact-form-7'])) { unset($wp_styles->registered['contact-form-7']); }
        // media-player
        wp_deregister_style('mediaelement');
        wp_deregister_style('wp-mediaelement');
    }
    add_action('wp_enqueue_scripts', 'force_remove_styles_func', 100);

    // ==========================
    // db optimizations
    // ==========================

    // remove revison post type
    // Completely remove revisions from all post types
    function disable_revisions_for_all_post_types() {
        foreach (get_post_types() as $post_type) { remove_post_type_support($post_type, 'revisions'); }
    }
    add_action('init', 'disable_revisions_for_all_post_types');
    // Prevent saving revisions by intercepting post data
    function prevent_revision_creation($data, $postarr) {
        if (isset($data['post_type']) && 'revision' === $data['post_type']) { return false; }
        return $data;
    }
    add_filter('wp_insert_post_data', 'prevent_revision_creation', 10, 2);
    // Clear existing revisions from the database (optional, for cleanup)
    function handle_revisions_on_save($post_id, $post, $update) {
        // Avoid infinite loops and ensure proper execution.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (wp_is_post_revision($post_id)) { return; }
        // Unregister the revision post type.
        global $wp_post_types;
        if (isset($wp_post_types['revision'])) { unset($wp_post_types['revision']); }
        // save post clean the db
        global $wpdb;
        $ids_to_delete = [];
        // Get all revision post IDs
        $db_clean_revisions = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision'");
        if (!empty($db_clean_revisions)) {
            $ids_to_delete = array_merge($ids_to_delete, array_column($db_clean_revisions, 'ID'));
        }
        // Get all 'customize_changeset' post IDs, excluding the newest 2
        $db_clean_customize_changeset = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'customize_changeset' ORDER BY post_date ASC");
        if (count($db_clean_customize_changeset) > 2) {
            $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_customize_changeset, 'ID'), 0, count($db_clean_customize_changeset) - 2));
        }
        // Get all 'auto-draft' post IDs, excluding the newest 2
        $db_clean_auto_draft = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' ORDER BY post_date ASC");
        if (count($db_clean_auto_draft) > 2) {
            $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_auto_draft, 'ID'), 0, count($db_clean_auto_draft) - 2));
        }
        // Delete all posts with the collected IDs
        if (!empty($ids_to_delete)) {
            foreach ($ids_to_delete as $post_id) {
                wp_delete_post($post_id, true);
            }
        }
        // global $wpdb;
        // $db_clean_revisions = $wpdb->get_results(" SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision' ");
        // $db_clean_customize_changeset = $wpdb->get_results(" SELECT ID FROM {$wpdb->posts} WHERE post_type = 'customize_changeset' ORDER BY post_date ASC ");
        // $db_clean_auto_draft = $wpdb->get_results(" SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' ORDER BY post_date ASC ");
        // /* Get IDs of entries to delete (all except the newest 2) */
        // if (count($db_clean_customize_changeset) > 2) { $ids_to_delete = array_slice(array_column($db_clean_customize_changeset, 'ID'), 0, count($db_clean_customize_changeset) - 2); }
        // if (count($db_clean_auto_draft) > 2) { $ids_to_delete = array_slice(array_column($db_clean_auto_draft, 'ID'), 0, count($db_clean_auto_draft) - 2); }
        // if (!empty($db_clean_results)) {
        //     foreach ($db_clean_results as $post) {
        //         wp_delete_post($post->ID, true);
        //     }
        // }
    }
    add_action('save_post', 'handle_revisions_on_save', 10, 3);

    // post meta table optimizations
    function force_remove_unwanted_post_meta_keys( $null, $object_id, $meta_key, $meta_value, $unique ) {
        // List of unwanted meta keys
        // plugins | Smush
        $unwanted_meta_keys = [
            'wp-smush-lossy',       // Smush lossy meta
            '_edit_lock',           // Post edit lock
            '_edit_last'            // Last edited user
        ];
        // Check if the current meta key is in the unwanted list
        if ( in_array( $meta_key, $unwanted_meta_keys, true ) ) {
            return true; // Returning true prevents the meta from being added
        }
        return $null;
    }
    add_filter( 'add_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );
    add_filter( 'update_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );
    add_filter( 'delete_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );

}
add_action('after_setup_theme', 'millers_theme_setup');