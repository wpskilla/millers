<?php get_header(); ?>

<style type="text/css">
.archive-pg {padding: 1rem 0 1.8rem;text-align: center;margin: auto;border-bottom: 1px solid #F2F2F2;margin-bottom: 2rem;}
.archive-pg .page-header {display: flex;flex-direction: column;max-width: 800px;margin: auto;}
.page-header .post-count span {display: inline-block;color: white;background-color: #191919;padding: 8px 16px;border-radius: 99em;margin-top: 2px;}
@media screen and (max-width: 600px) {
    .page-header .page-title {font-size: 28px;line-height: 38px;}
}
</style>

<main class="container">
    <!-- title -->
    <?php if (is_archive() || is_home()) : ?>
        <div class="archive-pg">
            <!-- header -->
            <div class="page-header">
                <h1 class="page-title">
                    <?php 
                        if (is_archive()) the_archive_title();
                        elseif (is_home()) echo get_the_title(get_option('page_for_posts'));
                    ?>
                </h1>
                <?php if (get_the_archive_description()) : ?>
                    <?php the_archive_description(); ?>
                <?php endif; ?>
                <p class="post-count">
                    <span>
                    <?php 
                        $total_posts = $wp_query->found_posts;
                        echo sprintf(__('%s Posts', 'millers'), millers_format_number($total_posts)); 
                    ?>
                    </span>
                </p>
            </div>
        </div>
    <?php endif; ?>
    <!-- main -->
    <?php
        if (have_posts()) {
            while (have_posts()) {
                the_post();
                get_template_part('template-parts/content', get_post_type());
            }
        } else { echo '<p>' . __('No content available.', 'my-starter-theme') . '</p>'; }
    ?>
    <!-- pagination -->
    <?php if (is_archive() || is_home()) : ?>
        <!-- post pagination -->
        <div class="pagination">
            <?php
            // Default WordPress pagination
            the_posts_pagination([
                'mid_size'  => 2,
                'prev_text' => __('&laquo; Previous', 'millers'),
                'next_text' => __('Next &raquo;', 'millers'),
            ]);
            ?>
        </div>
    <?php endif; ?>
</main>

<?php get_footer(); ?>