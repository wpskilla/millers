<?php
// Content template for posts
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php if (is_archive() || is_home()) : // archive ?>
        <!-- title -->
        <div class="post-header"><?php the_title('<h2 class="post-title"><a href="' . esc_url(get_permalink()) . '">', '</a></h2>'); ?></div>
        <!-- excerpt -->
        <div class="post-content"><?php the_excerpt(); ?></div>
        <!-- thumbnail -->
        <?php if (has_post_thumbnail()) : ?>
            <div class="post-thumbnail"><?php the_post_thumbnail('large', ['loading' => 'lazy']); ?></div>
        <?php endif; ?>
    <?php else : // single ?>
        <!-- title -->
        <h1 class="post-title"><?php the_title(); ?></h1>
        <!-- meta -->
        <div class="post-meta">
            <span>Published on <?php echo get_the_date(); ?></span>
            <span> | By <?php the_author_posts_link(); ?></span>
            <span> | Category: <?php the_category(', '); ?></span>
        </div>
        <!-- thumbnail -->
        <?php if (has_post_thumbnail()) : ?>
            <div class="post-thumbnail"><?php the_post_thumbnail('large', ['loading' => 'lazy']); ?></div>
        <?php endif; ?>
        <!-- content -->
        <div class="post-content"><?php the_content(); ?></div>
        <!-- after content sidebar -->
        <?php if (is_active_sidebar('post_after_content')) {dynamic_sidebar('post_after_content');} ?>
        <!-- tags -->
        <div class="post-tags"><span>Tags: <?php the_tags('', ', ', ''); ?></span></div>
        <!-- navigation -->
        <div class="post-navigation">
            <span><?php previous_post_link('← %link'); ?></span>
            <span><?php next_post_link('%link →'); ?></span>
        </div>
        <!-- post comments -->
        <?php if (comments_open() || get_comments_number()) : ?>
            <div class="comments-section"><?php comments_template(); ?></div>
        <?php endif; ?>
        <!-- related posts -->
        <?php
            $current_post_id = get_the_ID();
            $related_args = array(
                'category__in'   => wp_get_post_categories($current_post_id),
                'post__not_in'   => array($current_post_id), // Exclude the current post
                'posts_per_page' => 4, // Change the number of related posts
                'orderby'        => 'rand' // Display random related posts
            );
            $related_query = new WP_Query($related_args);
            if ($related_query->have_posts()) : ?>
            <div class="related-posts">
                <h3>Related Posts</h3>
                <ul>
                    <?php while ($related_query->have_posts()) : $related_query->the_post(); ?>
                        <li>
                            <a href="<?php the_permalink(); ?>">
                                <?php if (has_post_thumbnail()) { ?>
                                    <div class="related-post-thumb">
                                        <?php the_post_thumbnail('thumbnail'); ?>
                                    </div>
                                <?php } ?>
                                <span class="related-post-title"><?php the_title(); ?></span>
                            </a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            </div>
        <?php endif; wp_reset_postdata(); ?>
    <?php endif; ?>
</article>