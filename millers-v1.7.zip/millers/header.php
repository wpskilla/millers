<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
    <style type="text/css">
        /* Reset and general styles */
        :root{--primairy-color: #17938d;}
        body {margin: 0;padding: 0;font-family: cursive;line-height: 1.6;background-color: #f9f9f9;}
        body a {color: var(--primairy-color);}
        /* Header and Navigation */
        header {background-color: var(--primairy-color);padding: 1rem;margin-bottom: 1rem;border-radius: 5px;}
        header nav {position: relative;}
        header nav ul {list-style: none;margin: 0;padding: 0;display: flex;justify-content: center;gap: 1rem;position: relative;z-index: 999;}
        header nav ul li {position: relative;}
        header nav ul li a {text-decoration: none;color: #fff;font-weight: bold;padding: 0.5rem 1rem;border-radius: 5px;transition: background-color 0.3s;display: block;}
        /* Hover & Active Styles */
        header nav ul li a:hover,
        header nav ul li a[aria-current="page"] {background-color: white;color: black;}
        /* Submenu Styles */
        header nav ul li ul {list-style: none;margin: 0;padding: 0;position: absolute;top: 100%;left: 0;background-color: var(--primairy-color);border-radius: 5px;display: none;min-width: 150px;box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);}
        header nav ul li ul li {display: block;width: 100%;}
        header nav ul li ul li a {padding: 0.5rem 1rem;white-space: nowrap;color: #fff;}
        /* Show submenu on hover */
        header nav ul li:hover > ul {display: block;}
        /* Ensure submenu doesn't disappear on hover */
        header nav ul li ul li a:hover {background-color: #777;}
        #miller-menu-toggle {display: none;}
        header nav ul li.menu-item-has-children > a {position: relative;padding-right: 1.5rem; /* Space for arrow */}
        /* The down arrow */
        header nav ul li.menu-item-has-children > a::after {content: "▼";  /* Unicode for downward arrow */font-size: 8px;color: #fff;position: absolute;right: 11px;top: 50%;transform: translateY(-45%);transition: transform 0.3s;}
        /* Rotate arrow when hovered (desktop) */
        header nav ul li.menu-item-has-children:hover > a::after {transform: translateY(-50%) rotate(180deg);}
        /* Main Content */
        article {background-color: #fff;padding: 2rem;margin-bottom: 1rem;border-radius: 5px;box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);}
        article header h1,article header h2, article header a {color: white;}.page-header {margin-bottom: 2rem;}.page-header .page-title {color: white;margin: 0;}
        article h1,article h2 {color: #222;margin-bottom: 1rem;}
        article .post-thumbnail {text-align: center;margin-bottom: 20px;}
        article .post-thumbnail img {max-width: 100%;width: 100%;object-fit: cover;max-height: 550px;height: auto;border-radius: 8px;box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.06);}
        article p {margin-bottom: 1rem;}
        article .entry-content {max-width: 100%;margin: 0 auto;word-wrap: break-word;}
        article .entry-content img {max-width: 100%;width: 100%;object-fit: cover;max-height: 550px;height: auto;display: block;margin: 20px 0;border-radius: 8px;box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);}
        article .entry-content .wp-block-gallery img{margin: 0}
        article .entry-content iframe,article .entry-content embed,article .entry-content video {max-width: 100%;height: auto;display: block;margin: 20px 0;}
        article .entry-content blockquote {padding: 20px;margin: 20px 0;background-color: #f9f9f9;border-left: 4px solid #0073aa;font-style: italic;color: #555;}
        article .entry-content ul,article .entry-content ol {padding-left: 20px;margin: 20px 0;}footer a {color: white;}
        /* Footer */
        footer {background-color: var(--primairy-color);color: #fff;text-align: center;padding: 1rem 0;margin-top: 1rem;border-radius: 5px;}
        footer p {margin: 0;}
        /* Responsive Design */
        @media screen and (max-width: 768px) {
            header nav ul {flex-direction: column;align-items: center;}
            header nav ul li {margin-bottom: 0.5rem;}
            header nav ul {flex-direction: column;position: absolute;top: 100%;left: 0;width: 100%;background-color: var(--primairy-color);display: none;padding: 1rem;}
            /* Show menu when toggled */
            header nav ul.menu-open {display: flex;}
            header nav ul li {text-align: center;width: 100%;}
            /* Submenu positioning in mobile */
            header nav ul li ul {position: relative;top: 0;left: 0;background-color: #444;display: none;width: 100%;text-align: center;}
            /*header nav ul li:hover > ul,
            header nav ul li ul.menu-open {display: block;}*/
            /* Mobile Menu Toggle Button */
            #miller-menu-toggle {background: none;border: none;font-size: 2rem;color: #fff;cursor: pointer;display: block;margin: 0 auto;}
            header nav ul li.menu-item-has-children > a::after {right: 1rem;content: none;}
        }
    </style>
</head>
<body <?php body_class(); ?>>
    <div class="container">
        <header>
            <nav>
                <button id="miller-menu-toggle" aria-label="Toggle Menu">☰</button>
                <?php
                    wp_nav_menu([
                        'theme_location' => 'primary',
                        'container' => false,
                        'menu_class' => 'menu',
                    ]);
                ?>
            </nav>
        </header>
    </div>