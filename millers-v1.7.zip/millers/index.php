<?php get_header(); ?>

<main class="container">
    <!-- title -->
    <?php if (is_archive()) : ?>
        <header class="page-header">
            <h1 class="page-title">
                <?php the_archive_title(); ?>
            </h1>
        </header>
    <?php endif; ?>
    <!-- main -->
    <?php
        if (have_posts()) {
            while (have_posts()) {
                the_post();
                get_template_part('template-parts/content', get_post_type());
            }
        } else { echo '<p>' . __('No content available.', 'my-starter-theme') . '</p>'; }
    ?>
    <!-- pagination -->
    <?php if (is_archive() || is_home()) : ?>
        <!-- post pagination -->
        <div class="pagination">
            <?php
            // Default WordPress pagination
            the_posts_pagination([
                'mid_size'  => 2,
                'prev_text' => __('&laquo; Previous', 'textdomain'),
                'next_text' => __('Next &raquo;', 'textdomain'),
            ]);
            ?>
        </div>
    <?php endif; ?>
</main>

<?php get_footer(); ?>