<?php

// Theme setup
function millers_theme_setup() {
    // theme supports
    add_theme_support('title-tag');add_theme_support('post-thumbnails');
    add_theme_support('woocommerce');
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
    // menus
    register_nav_menus([ 'primary' => __('Primary Menu', 'my-starter-theme'), ]);
}
add_action('after_setup_theme', 'millers_theme_setup');

require_once get_template_directory() . '/inc/core-functions.php';
require_once get_template_directory() . '/inc/db-functions.php';


