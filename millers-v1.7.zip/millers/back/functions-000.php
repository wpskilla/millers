<?php

// Theme setup
function millers_theme_setup() {

    // ==========================
    // default code
    // ==========================

    include_once(ABSPATH . 'wp-admin/includes/plugin.php');

    // theme supports
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');

    // menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'my-starter-theme'),
    ]);

    // ==========================
    // db controller | remove revisions | post save | meta crud | nav menu update | activate/deactivate
    // ==========================

    // remove revision
    function disable_revisions_for_all_post_types() {
        foreach (get_post_types() as $post_type) { remove_post_type_support($post_type, 'revisions'); }
    }
    add_action('init', 'disable_revisions_for_all_post_types');
    function prevent_revision_creation($data, $postarr) {
        if (isset($data['post_type']) && 'revision' === $data['post_type']) { return false; }
        return $data;
    }
    add_filter('wp_insert_post_data', 'prevent_revision_creation', 10, 2);

    // post save
    function db_clean_on_save_post($post_id, $post, $update) {
        // Avoid infinite loops and ensure proper execution.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (wp_is_post_revision($post_id)) { return; }
        // Unregister the revision post type.
        global $wp_post_types;
        if (isset($wp_post_types['revision'])) { unset($wp_post_types['revision']); }

        // clean wp_posts table | revisions | auto-drafts | customize_changeset
        global $wpdb;
        $ids_to_delete = [];
        // Get all revision post IDs
        $db_clean_revisions = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision'");
        if (!empty($db_clean_revisions)) {
            $ids_to_delete = array_merge($ids_to_delete, array_column($db_clean_revisions, 'ID'));
        }
        // Get all 'customize_changeset' post IDs, excluding the newest 2
        $db_clean_customize_changeset = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'customize_changeset' ORDER BY post_date ASC");
        if (count($db_clean_customize_changeset) > 2) {
            $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_customize_changeset, 'ID'), 0, count($db_clean_customize_changeset) - 2));
        }
        // Get all 'auto-draft' post IDs, excluding the newest 2
        $db_clean_auto_draft = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' ORDER BY post_date ASC");
        if (count($db_clean_auto_draft) > 2) {
            $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_auto_draft, 'ID'), 0, count($db_clean_auto_draft) - 2));
        }
        // Delete all posts with the collected IDs
        if (!empty($ids_to_delete)) {
            foreach ($ids_to_delete as $post_id) {
                wp_delete_post($post_id, true);
            }
        }

        // clean wp_postmeta table | wp | Smush | FakerPress
        $db_clean_meta_keys_arr = [
            '_edit_lock',
            '_edit_last',
            '_encloseme',
            'wp-smush-lossy',
            'fakerpress_flag',
            '_fakerpress_orginal_url',
        ];
        // Delete unwanted post meta keys
        foreach ($db_clean_meta_keys_arr as $meta_key) {
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s",
                    $meta_key
                )
            );
        }
    }
    add_action('save_post', 'db_clean_on_save_post', 10, 3);

    // nav menu update
    add_action('wp_update_nav_menu', 'schedule_cleanup_after_menu_update', 10, 1);
    function schedule_cleanup_after_menu_update($menu_id) {
        // Ensure the menu ID is valid
        if (!$menu_id) { return; }
        // Delay cleanup until the request is finished
        add_action('shutdown', 'cleanup_nav_menu_item_drafts');
    }
    function cleanup_nav_menu_item_drafts() {
        global $wpdb;
        // removing draft nav_menu_item no menu
        $orphaned_nav_menu_items = $wpdb->get_results("
            SELECT p.ID FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
            WHERE p.post_type = 'nav_menu_item' 
            AND p.post_status = 'draft' 
            AND tr.object_id IS NULL
        ");
        if (!empty($orphaned_nav_menu_items)) {
            foreach ($orphaned_nav_menu_items as $post) {
                wp_delete_post($post->ID, true);
            }
        }
    }

    // meta crud | removing meta keys
    function force_remove_unwanted_post_meta_keys( $null, $object_id, $meta_key, $meta_value, $unique ) {
        // clean wp_postmeta table | wp | Smush
        $unwanted_meta_keys = [
            'wp-smush-lossy',
            '_edit_lock',
            '_edit_last',
        ];
        // Check if the current meta key is in the unwanted list
        if ( in_array( $meta_key, $unwanted_meta_keys, true ) ) {
            return true; // Returning true prevents the meta from being added
        }
        return $null;
    }
    add_filter( 'add_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );
    add_filter( 'update_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );
    add_filter( 'delete_post_metadata', 'force_remove_unwanted_post_meta_keys', 10, 5 );

    // activate/deactivate

    // ==========================
    // resources controller
    // ==========================

    // remove actions
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );

    // head action
    function preload_images() {
        echo '<link rel="preload" href="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZWVlZWVlIiAvPjwvc3ZnPg==" as="image" type="image/svg+xml">';
    }
    add_action('wp_head', 'preload_images');

    // forced removing styles
    // function force_remove_styles_func() {
    //     if (!is_admin()) {
    //         // Forminator form
    //         if (is_plugin_active('forminator/forminator.php')) {
    //             wp_enqueue_style('forminator-all-styles', get_template_directory_uri() . '/assets/plugin/forminator/forminator-all-styles.css', array(), null, 'all');
    //         }
    //         // WooCommerce
    //         if (is_plugin_active('woocommerce/woocommerce.php')) {
    //             wp_dequeue_style('woocommerce-layout');wp_deregister_style('woocommerce-layout');
    //             wp_dequeue_style('woocommerce-smallscreen');wp_deregister_style('woocommerce-smallscreen');
    //             wp_dequeue_style('woocommerce-general');wp_deregister_style('woocommerce-general');
    //             wp_dequeue_style('brands-styles');wp_deregister_style('brands-styles');
    //             wp_enqueue_style('woocommerce-starter-styles', get_template_directory_uri() . '/assets/plugin/woocommerce/woocommerce-starter-styles.css', array(), null, 'all');
    //         }
    //         // Ultimate Member
    //         if (is_plugin_active('ultimate-member/ultimate-member.php')) {
    //             wp_enqueue_style('ultimate-member-styles', get_template_directory_uri() . '/assets/plugin/ultimate-member/ultimate-member-styles.min.css', array(), null, 'all');
    //         }
    //     }
    // }
    // add_action('wp_enqueue_scripts', 'force_remove_styles_func', 999);
    // strongle removing styles
    // function remove_unwanted_styles($buffer) {
    //     if (is_admin() || is_user_logged_in()) {
    //         return $buffer; // Skip processing for admin or logged-in users
    //     }
    //     // default patterns
    //     $patterns = [];
    //     if (is_plugin_active('forminator/forminator.php')) {
    //         $forminator_arr = [
    //             '/<link[^>]+forminator-icons-css[^>]+>\s*/i',
    //             '/<link[^>]+forminator-utilities-css[^>]+>\s*/i',
    //             '/<link[^>]+forminator-grid-default-css[^>]+>\s*/i',
    //             '/<link[^>]+forminator-forms-default-base-css[^>]+>\s*/i',
    //             '/<link[^>]+forminator-forms-default-select2-css[^>]+>\s*/i',
    //             '/<link[^>]+intlTelInput-forminator-css-css[^>]+>\s*/i',
    //         ];
    //         $patterns = array_merge($patterns, $forminator_arr);
    //     }
    //     if (is_plugin_active('ultimate-member/ultimate-member.php')) {
    //         $ultimate_mem_arr = [
    //             '/<link[^>]+um_modal-css[^>]+>\s*/i',
    //             '/<link[^>]+um_ui-css[^>]+>\s*/i',
    //             '/<link[^>]+um_tipsy-css[^>]+>\s*/i',
    //             '/<link[^>]+um_raty-css[^>]+>\s*/i',
    //             '/<link[^>]+um_fileupload-css[^>]+>\s*/i',
    //             '/<link[^>]+um_confirm-css[^>]+>\s*/i',
    //             '/<link[^>]+um_datetime-css[^>]+>\s*/i',
    //             '/<link[^>]+um_datetime_date-css[^>]+>\s*/i',
    //             '/<link[^>]+um_datetime_time-css[^>]+>\s*/i',
    //             '/<link[^>]+um_fonticons_ii-css[^>]+>\s*/i',
    //             '/<link[^>]+um_fonticons_fa-css[^>]+>\s*/i',
    //             '/<link[^>]+um_fontawesome-css[^>]+>\s*/i',
    //             '/<link[^>]+um_common-css[^>]+>\s*/i',
    //             '/<link[^>]+um_responsive-css[^>]+>\s*/i',
    //             '/<link[^>]+um_styles-css[^>]+>\s*/i',
    //             '/<link[^>]+um_crop-css[^>]+>\s*/i',
    //             '/<link[^>]+um_profile-css[^>]+>\s*/i',
    //             '/<link[^>]+um_account-css[^>]+>\s*/i',
    //             '/<link[^>]+um_misc-css[^>]+>\s*/i',
    //             '/<link[^>]+um_default_css-css[^>]+>\s*/i',
    //         ];
    //         $patterns = array_merge($patterns, $ultimate_mem_arr);
    //     }
    //     // Remove unwanted links and collapse extra spaces/new lines
    //     $buffer = preg_replace($patterns, '', $buffer);
    //     $buffer = preg_replace('/\n\s*\n/', "\n", $buffer); // Remove multiple empty lines
    //     return trim($buffer); // Trim leading/trailing spaces
    // }
    // function buffer_start() {
    //     // Run only for non-logged-in frontend users
    //     if (!is_admin() && !is_user_logged_in()) { ob_start('remove_unwanted_styles'); }
    // }
    // function buffer_end() {
    //     if (!is_admin() && !is_user_logged_in()) { ob_end_flush(); }
    // }
    // add_action('template_redirect', 'buffer_start');
    // add_action('shutdown', 'buffer_end');

}
add_action('after_setup_theme', 'millers_theme_setup');




