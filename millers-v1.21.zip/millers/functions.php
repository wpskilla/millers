<?php

// Theme setup
function millers_theme_setup() {
    // Enable support for document title
    add_theme_support('title-tag');

    // Enable support for featured images (post thumbnails)
    add_theme_support('post-thumbnails');

    // Enable support for WooCommerce (if using an eCommerce store)
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    // Enable support for automatic feed links
    add_theme_support('automatic-feed-links');

    // Enable support for HTML5 markup structure
    add_theme_support('html5', [ 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'script', 'style' ]);

    // Enable support for selective refresh for widgets (better performance in Customizer)
    add_theme_support('customize-selective-refresh-widgets');

    // Enable support for editor styles (Gutenberg)
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor-style.css'); // Link to custom editor styles

    // Enable support for responsive embedded content
    add_theme_support('responsive-embeds');

    // Enable support for post formats
    add_theme_support('post-formats', ['aside', 'image', 'video', 'quote', 'link', 'gallery', 'audio']);

    // Enable support for WooCommerce block styles
    add_theme_support('wp-block-styles');

    // Enable support for widgets block editor
    add_theme_support('widgets-block-editor');

    // Register theme menus
    register_nav_menus([ 'primary' => __('Primary Menu', 'my-starter-theme'), ]);

    // widgets
    function millers_widgets_init() {
        register_sidebar([
            'name'          => __('Sidebar', 'millers'),
            'id'            => 'sidebar-1',
            'description'   => __('Main sidebar for widgets.', 'millers'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ]);

        register_sidebar(array(
            'name'          => __('Post - After Content', 'millers'),
            'id'            => 'post_after_content',
            'before_widget' => '<div class="single-widget after-content">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ));
    }
    add_action('widgets_init', 'millers_widgets_init');

    // search query
    add_action('pre_get_posts', function($query) {
        if ($query->is_search() && !is_admin()) {
            $post_types = get_post_types(['public' => true], 'names');
            unset($post_types['page']);
            $query->set('post_type', $post_types);
        }
    });

    // removing unwanted images sizes
    function disable_unused_image_sizes($sizes) {
        unset($sizes['medium_large']);
        unset($sizes['1536x1536']);
        unset($sizes['2048x2048']);
        return $sizes;
    }
    add_filter('intermediate_image_sizes_advanced', 'disable_unused_image_sizes');

}
add_action('after_setup_theme', 'millers_theme_setup');

require_once get_template_directory() . '/inc/core-functions.php';
require_once get_template_directory() . '/inc/db-functions.php';
require_once get_template_directory() . '/inc/cron-jobs.php';
require_once get_template_directory() . '/inc/widgets.php';

// elementor
add_action('elementor/elements/categories_registered', function ($elements_manager) {
    $elements_manager->add_category(
        'millers-widgets',
        [
            'title' => 'Millers Widgets',
            'icon' => 'fa fa-plug'
        ]
    );
});
function millers_elementor_widgets_register($widgets_manager) {
    require_once(get_template_directory() . '/elements/class-millers-wpquery.php');
    $widgets_manager->register(new \Millers_Wp_Query_Widget());
    require_once(get_template_directory() . '/elements/millers-taxonomy-list.php');
    $widgets_manager->register(new \Millers_Taxonomy_List_Widget());
    require_once(get_template_directory() . '/elements/class-millers-search.php');
    $widgets_manager->register(new \Millers_Search_Widget());
}
add_action('elementor/widgets/register', 'millers_elementor_widgets_register');


