<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Millers_Taxonomy_List_Widget extends Widget_Base
{
    public function get_name()
    {
        return 'millers-taxonomy-list';
    }

    public function get_title()
    {
        return 'Millers Taxonomy List';
    }

    public function get_icon()
    {
        return 'eicon-post-list';
    }

    public function get_categories()
    {
        return ['millers-widgets'];
    }

    protected function register_controls()
    {
        // CONTENT TAB
        $this->start_controls_section('content_section', [
            'label' => 'Content',
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        // Taxonomy Selection
        $this->add_control(
            'taxonomy_type',
            [
                'label' => 'Select Taxonomy',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'category' => 'Categories',
                    'post_tag' => 'Tags',
                ],
                'default' => 'category',
            ]
        );

        // Limit Terms
        $this->add_control(
            'max_terms',
            [
                'label' => 'Maximum Terms to Display',
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
                'step' => 1,
                'default' => 20,
            ]
        );

        $this->end_controls_section();

        // STYLE TAB: Container Styles (.taxonomy-list)
        $this->start_controls_section('container_style_section', [
            'label' => 'Container',
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        // Flex Layout
        $this->add_control(
            'flex_direction',
            [
                'label' => 'Flex Direction',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'row' => 'Row',
                    'row-reverse' => 'Row Reverse',
                    'column' => 'Column',
                    'column-reverse' => 'Column Reverse',
                ],
                'default' => 'row',
                'selectors' => ['{{WRAPPER}} .taxonomy-list' => 'flex-direction: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'flex_gap',
            [
                'label' => 'Gap',
                'type' => Controls_Manager::SLIDER,
                'range' => ['px' => ['min' => 0, 'max' => 100]],
                'selectors' => ['{{WRAPPER}} .taxonomy-list' => 'gap: {{SIZE}}{{UNIT}};'],
            ]
        );

        $this->add_control(
            'align_items',
            [
                'label' => 'Align Items',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'flex-start' => 'Flex Start',
                    'center' => 'Center',
                    'flex-end' => 'Flex End',
                    'stretch' => 'Stretch',
                ],
                'default' => 'center',
                'selectors' => ['{{WRAPPER}} .taxonomy-list' => 'align-items: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'justify_content',
            [
                'label' => 'Justify Content',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'flex-start' => 'Flex Start',
                    'center' => 'Center',
                    'flex-end' => 'Flex End',
                    'space-between' => 'Space Between',
                    'space-around' => 'Space Around',
                    'space-evenly' => 'Space Evenly',
                ],
                'default' => 'flex-start',
                'selectors' => ['{{WRAPPER}} .taxonomy-list' => 'justify-content: {{VALUE}};'],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            ['name' => 'container_border', 'selector' => '{{WRAPPER}} .taxonomy-list']
        );

        $this->add_control(
            'container_padding',
            [
                'label' => 'Padding',
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => ['{{WRAPPER}} .taxonomy-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            ['name' => 'container_background', 'selector' => '{{WRAPPER}} .taxonomy-list']
        );

        $this->end_controls_section();

        // STYLE TAB: Link Styles (.taxonomy-list a)
        $this->start_controls_section('link_style_section', [
            'label' => 'Link',
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            ['name' => 'link_typography', 'selector' => '{{WRAPPER}} .taxonomy-list a']
        );

        $this->add_control(
            'link_color',
            [
                'label' => 'Text Color',
                'type' => Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .taxonomy-list a' => 'color: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'link_hover_color',
            [
                'label' => 'Hover Color',
                'type' => Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .taxonomy-list a:hover' => 'color: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'link_background',
            [
                'label' => 'Background Color',
                'type' => Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .taxonomy-list a' => 'background-color: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'link_hover_background',
            [
                'label' => 'Hover Background Color',
                'type' => Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} .taxonomy-list a:hover' => 'background-color: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'link_padding',
            [
                'label' => 'Padding',
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => ['{{WRAPPER}} .taxonomy-list a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            ['name' => 'link_border', 'selector' => '{{WRAPPER}} .taxonomy-list a']
        );

        $this->add_control(
            'link_border_radius',
            [
                'label' => 'Border Radius',
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => ['{{WRAPPER}} .taxonomy-list a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $taxonomy = $settings['taxonomy_type'];
        $max_terms = !empty($settings['max_terms']) ? intval($settings['max_terms']) : 20;

        $terms = get_terms([
            'taxonomy' => $taxonomy,
            'hide_empty' => true,
            'number' => $max_terms, // Limit terms to max_terms setting
        ]);
        ob_start(); ?>

        <style type="text/css">
            .taxonomy-list {list-style: none;padding: 0;margin: 0;}
            .taxonomy-list li {display: flex;align-items: center;}
            .taxonomy-list a {display: inline-block;text-decoration: none;transition: all 0.3s ease;}
        </style>

        <?php if (!empty($terms) && !is_wp_error($terms)) { ?>
            <ul class="taxonomy-list" style="display: flex; flex-wrap: wrap;">
            <?php foreach ($terms as $term) { ?>
                <li><a href="<?php echo get_term_link($term); ?>"><?php echo esc_html($term->name); ?></a></li>
            <?php } ?>
            </ul>
        <?php } else { ?>
            <p>No items found.</p>
        <?php }
        echo ob_get_clean();
    }

}
