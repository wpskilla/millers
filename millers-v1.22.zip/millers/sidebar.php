<?php
/**
 * The Sidebar containing the main widget area.
 *
 * @package Millers Theme
 */

if (!is_active_sidebar('sidebar-1')) {
    return; // Exit if no widgets are active
}
?>

<div class="container">
    <aside id="secondary" class="widget-area">
        <?php dynamic_sidebar('sidebar-1'); ?>
    </aside><!-- #secondary -->
</div>
