<?php



// ==========================
// db controller | remove revisions | post save | meta crud | nav menu update | activate | deactivate
// ==========================

// remove revision
function disable_revisions_for_all_post_types() { foreach (get_post_types() as $post_type) { remove_post_type_support($post_type, 'revisions'); } }
add_action('init', 'disable_revisions_for_all_post_types');
function prevent_revision_creation($data, $postarr) {
    if (isset($data['post_type']) && 'revision' === $data['post_type']) { return false; }
    return $data;
}
add_filter('wp_insert_post_data', 'prevent_revision_creation', 10, 2);

// post save
function db_clean_on_save_post($post_id, $post, $update) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (wp_is_post_revision($post_id)) { return; }
    global $wp_post_types;
    if (isset($wp_post_types['revision'])) { unset($wp_post_types['revision']); }
    // clean wp_posts table | revisions | auto-drafts | customize_changeset
    global $wpdb;
    $ids_to_delete = [];
    $db_clean_revisions = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision'");
    if (!empty($db_clean_revisions)) {
        $ids_to_delete = array_merge($ids_to_delete, array_column($db_clean_revisions, 'ID'));
    }
    $db_clean_customize_changeset = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'customize_changeset' ORDER BY post_date ASC");
    if (count($db_clean_customize_changeset) > 2) {
        $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_customize_changeset, 'ID'), 0, count($db_clean_customize_changeset) - 2));
    }
    $db_clean_auto_draft = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' ORDER BY post_date ASC");
    if (count($db_clean_auto_draft) > 2) {
        $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_auto_draft, 'ID'), 0, count($db_clean_auto_draft) - 2));
    }
    if (!empty($ids_to_delete)) {
        foreach ($ids_to_delete as $post_id) { wp_delete_post($post_id, true); }
    }
    // clean post meta
    $db_clean_meta_keys_arr = [
        '_edit_lock',
        '_edit_last',
        '_encloseme',
        'wp-smush-lossy',
        'fakerpress_flag',
        '_fakerpress_orginal_url',
        '_astra_sites_imported_post',
        '_astra_sites_enable_for_batch',
        '_astra_sites_image_hash',
        '_elementor_source_image_hash',
        '_astra_sites_imported_wp_forms',
        '_wxr_import_user_slug',
        '_locale',
        '_hash',
    ];
    foreach ($db_clean_meta_keys_arr as $meta_key) {
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", $meta_key ) );
    }
    $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_value = '' OR meta_value IS NULL");
    // clean wp options
    $wpdb->query(
        "DELETE FROM $wpdb->options WHERE option_name LIKE '_transient%' AND option_value < NOW()"
    );
}
add_action('save_post', 'db_clean_on_save_post', 10, 3);

// clean draft menu
add_action('wp_update_nav_menu', 'schedule_cleanup_after_menu_update', 10, 1);
function schedule_cleanup_after_menu_update($menu_id) {
    if (!$menu_id) { return; }
    add_action('shutdown', 'cleanup_nav_menu_item_drafts');
}
function cleanup_nav_menu_item_drafts() {
    global $wpdb;
    $orphaned_nav_menu_items = $wpdb->get_results("
        SELECT p.ID FROM {$wpdb->posts} p
        LEFT JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
        WHERE p.post_type = 'nav_menu_item' AND p.post_status = 'draft' AND tr.object_id IS NULL
    ");
    if (!empty($orphaned_nav_menu_items)) {
        foreach ($orphaned_nav_menu_items as $post) { wp_delete_post($post->ID, true); }
    }
}

// meta crud | removing meta keys
function force_update_post_meta_keys( $null, $object_id, $meta_key, $meta_value, $unique ) {
    $unwanted_meta_keys = [ '_edit_lock', '_edit_last', ];
    if ( in_array( $meta_key, $unwanted_meta_keys, true ) ) { return true; }
    return $null;
}
add_filter( 'add_post_metadata', 'force_update_post_meta_keys', 10, 5 );
add_filter( 'update_post_metadata', 'force_update_post_meta_keys', 10, 5 );
add_filter( 'delete_post_metadata', 'force_update_post_meta_keys', 10, 5 );



