<?php

function millers_import_files() {
    return [
        [
            'import_file_name'           => 'BlogZine Millers',
            'import_file_url'            => get_template_directory_uri() . '/inc/demo/blogzine-content.xml',
            'import_preview_image_url'   => get_template_directory_uri() . '/inc/demo/preview.jpg',
            'import_customizer_file_url' => get_template_directory_uri() . '/inc/demo/blogzine-customizer.dat',
            'required_plugins'           => ['elementor', 'header-footer-elementor', 'elementskit-lite', 'fluentform', 'add-to-any'],
            'preview_url'                => 'https://blogzine.wpskilla.com/',
        ]
    ];
}
add_filter('pt-ocdi/import_files', 'millers_import_files');


// pending modules | elementor global styles | fluent form import


function millers_after_import_setup() {
    // Set home and blog pages
    $home = get_page_by_title('Home BlogZine');
    $blog = get_page_by_title('Blog BlogZine');
    
    if ($home) {
        update_option('page_on_front', $home->ID);
        update_option('show_on_front', 'page');
    }
    
    if ($blog) {
        update_option('page_for_posts', $blog->ID);
    }

    // Assign menus
    $menu = get_term_by('name', 'Main Menu BlogZine', 'nav_menu');
    if ($menu) {
        set_theme_mod('nav_menu_locations', ['primary' => $menu->term_id]);
    }

    // addtoany
    $addtoany_options = [
        "position" => "bottom",
        "display_in_posts_on_front_page" => "1",
        "display_in_posts_on_archive_pages" => "-1",
        "display_in_excerpts" => "-1",
        "display_in_posts" => "1",
        "display_in_pages" => "-1",
        "display_in_attachments" => "-1",
        "display_in_feed" => "1",
        "icon_size" => "32",
        "icon_bg" => "original",
        "icon_bg_color" => "#2a2a2a",
        "icon_fg" => "original",
        "icon_fg_color" => "#ffffff",
        "button" => "A2A_SVG_32",
        "button_custom" => "",
        "button_show_count" => "-1",
        "header" => "",
        "additional_js_variables" => "",
        "additional_css" => "",
        "custom_icons" => "-1",
        "custom_icons_url" => "/",
        "custom_icons_type" => "png",
        "custom_icons_width" => "",
        "custom_icons_height" => "",
        "cache" => "-1",
        "display_in_cpt_e-floating-buttons" => "-1",
        "display_in_cpt_elementor_library" => "-1",
        "display_in_cpt_elementskit_content" => "-1",
        "display_in_cpt_elementskit_template" => "-1",
        "display_in_cpt_elementor-hf" => "-1",
        "button_text" => "Share",
        "active_services" => ["facebook", "email", "pinterest", "whatsapp", "google_gmail", "x", "wordpress"],
        "special_facebook_like_options" => ["show_count" => "-1", "verb" => "like"],
        "special_twitter_tweet_options" => ["show_count" => "-1"],
        "special_pinterest_pin_options" => ["show_count" => "-1"],
        "special_pinterest_options" => ["show_count" => "-1"]
    ];
    update_option('addtoany_options', $addtoany_options);

    // fluentform
    millers_create_fluent_form_newsletter();
}
function millers_create_fluent_form_newsletter() {
    if (!class_exists('\FluentForm\App\Models\Form')) {
        error_log("Fluent Forms plugin not installed or activated.");
        return;
    }

    // Check if the form already exists
    $existing_form = \FluentForm\App\Models\Form::where('title', 'Subscribe Newsletter')->first();
    if ($existing_form) {
        error_log("Fluent Form 'Subscribe Newsletter' already exists.");
        return;
    }

    // Form fields structure
    $form_fields = [
        'fields' => [
            [
                'element' => 'input_text',
                'attributes' => [
                    'name' => 'name',
                    'type' => 'text',
                    'placeholder' => 'Enter your name',
                    'id' => 'name_' . uniqid()
                ],
                'settings' => [
                    'label' => 'Full Name',
                    'validation_rules' => [
                        'required' => [
                            'value' => true,
                            'message' => 'Name is required'
                        ]
                    ]
                ]
            ],
            [
                'element' => 'input_email',
                'attributes' => [
                    'name' => 'email',
                    'type' => 'email',
                    'placeholder' => 'Enter your email',
                    'id' => 'email_' . uniqid()
                ],
                'settings' => [
                    'label' => 'Email Address',
                    'validation_rules' => [
                        'required' => [
                            'value' => true,
                            'message' => 'Email is required'
                        ],
                        'email' => [
                            'value' => true,
                            'message' => 'Enter a valid email address'
                        ]
                    ]
                ]
            ]
        ],
        'submitButton' => [
            'element' => 'button',
            'attributes' => [
                'type' => 'submit',
                'class' => 'ff-btn-primary'
            ],
            'settings' => [
                'button_ui' => [
                    'text' => 'Subscribe Now'
                ],
                'normal_styles' => [
                    'backgroundColor' => '#0073aa',
                    'color' => '#ffffff'
                ],
                'hover_styles' => [
                    'backgroundColor' => '#ffffff',
                    'color' => '#0073aa'
                ]
            ]
        ]
    ];

    // Create the form
    $form = new \FluentForm\App\Models\Form();
    $form->title = 'Subscribe Newsletter';
    $form->status = 'published';
    $form->type = 'form';
    $form->form_fields = json_encode($form_fields);
    $form->save();

    error_log("Fluent Form 'Subscribe Newsletter' Created Successfully!");
}
add_action('ocdi/after_import', 'millers_after_import_setup');



