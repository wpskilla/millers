<?php

// Theme setup
function millers_theme_setup() {
    // Enable support for document title
    add_theme_support('title-tag');

    // Enable support for featured images (post thumbnails)
    add_theme_support('post-thumbnails');

    // Enable support for WooCommerce (if using an eCommerce store)
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    // Enable support for automatic feed links
    add_theme_support('automatic-feed-links');

    // Enable support for HTML5 markup structure
    add_theme_support('html5', [ 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'script', 'style' ]);

    // Enable support for selective refresh for widgets (better performance in Customizer)
    add_theme_support('customize-selective-refresh-widgets');

    // Enable support for editor styles (Gutenberg)
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor-style.css'); // Link to custom editor styles

    // Enable support for responsive embedded content
    add_theme_support('responsive-embeds');

    // Enable support for post formats
    add_theme_support('post-formats', ['aside', 'image', 'video', 'quote', 'link', 'gallery', 'audio']);

    // Enable support for WooCommerce block styles
    add_theme_support('wp-block-styles');

    // Enable support for widgets block editor
    add_theme_support('widgets-block-editor');

    // Register theme menus
    register_nav_menus([ 'primary' => __('Primary Menu', 'my-starter-theme'), ]);

    // widgets
    function millers_widgets_init() {
        register_sidebar([
            'name'          => __('Sidebar', 'millers'),
            'id'            => 'sidebar-1',
            'description'   => __('Main sidebar for widgets.', 'millers'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ]);
    }
    add_action('widgets_init', 'millers_widgets_init');

}
add_action('after_setup_theme', 'millers_theme_setup');

require_once get_template_directory() . '/inc/core-functions.php';
require_once get_template_directory() . '/inc/db-functions.php';


