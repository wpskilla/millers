<?php
// Content template for posts
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '">', '</a></h2>'); ?>
    </header>
    <?php if (is_archive() || is_home()) : ?>
        <div class="entry-content">
            <?php the_excerpt(); ?>
        </div>
        <!-- thumbnail -->
        <?php if (has_post_thumbnail()) : ?>
            <div class="post-thumbnail">
                <?php the_post_thumbnail('large'); ?>
            </div>
        <?php endif; ?>
    <?php else : ?>
        <!-- thumbnail -->
        <?php if (has_post_thumbnail()) : ?>
            <div class="post-thumbnail">
                <?php the_post_thumbnail('large'); ?>
            </div>
        <?php endif; ?>
        <!-- content -->
        <div class="entry-content">
            <?php the_content(); ?>
        </div>
        <!-- post comments -->
        <?php if (comments_open() || get_comments_number()) : ?>
            <div class="comments-section">
                <?php comments_template(); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</article>