<?php



// ==========================
// db | revisions | post_save | meta_update | menu_update | daily schedule
// ==========================

// remove revision
function disable_revisions_for_all_post_types() { foreach (get_post_types() as $post_type) { remove_post_type_support($post_type, 'revisions'); } }
add_action('init', 'disable_revisions_for_all_post_types');
function prevent_revision_creation($data, $postarr) {
    if (isset($data['post_type']) && 'revision' === $data['post_type']) { return false; }
    return $data;
}
add_filter('wp_insert_post_data', 'prevent_revision_creation', 10, 2);

// post save
function db_clean_on_save_post($post_id, $post, $update) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (wp_is_post_revision($post_id)) { return; }
    global $wp_post_types;
    if (isset($wp_post_types['revision'])) { unset($wp_post_types['revision']); }
    // clean wp_posts table | revisions | auto-drafts | customize_changeset
    global $wpdb;
    $ids_to_delete = [];
    // revisions
    $db_clean_revisions = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision'");
    if (!empty($db_clean_revisions)) {
        $ids_to_delete = array_merge($ids_to_delete, array_column($db_clean_revisions, 'ID'));
    }
    // customize changes sets
    $db_clean_customize_changeset = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'customize_changeset' ORDER BY post_date ASC");
    if (count($db_clean_customize_changeset) > 2) {
        $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_customize_changeset, 'ID'), 0, count($db_clean_customize_changeset) - 2));
    }
    // auto drafts
    $db_clean_auto_draft = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' ORDER BY post_date ASC");
    if (count($db_clean_auto_draft) > 2) {
        $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_auto_draft, 'ID'), 0, count($db_clean_auto_draft) - 2));
    }
    // trash
    $db_clean_trash = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_status = 'trash' ORDER BY post_date ASC");
    if (count($db_clean_trash) > 15) {
        $ids_to_delete = array_merge($ids_to_delete, array_slice(array_column($db_clean_trash, 'ID'), 0, count($db_clean_trash) - 12));
    }
    // delete posts
    if (!empty($ids_to_delete)) {
        foreach ($ids_to_delete as $post_id) { wp_delete_post($post_id, true); }
    }
    // clean post meta
    $db_clean_meta_keys_arr = [ '_edit_lock','_edit_last','_encloseme','wp-smush-lossy','fakerpress_flag','_fakerpress_orginal_url','_astra_sites_imported_post','_astra_sites_enable_for_batch','_astra_sites_image_hash','_astra_sites_imported_wp_forms','_elementor_source_image_hash','_wxr_import_user_slug','_wxr_import_has_attachment_refs','_locale','_hash','tmpcoder_old_id','_tmpcoder_imported_post','_tmpcoder_enable_for_batch','_tmpcoder_image_hash', ];
    foreach ($db_clean_meta_keys_arr as $meta_key) {
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", $meta_key ) );
    }
    // clean empty/null post meta
    $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_value = '' OR meta_value IS NULL");
    // clean wp options
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient%' AND option_value < NOW()");
}
add_action('save_post', 'db_clean_on_save_post', 10, 3);

// clean draft menu
add_action('wp_update_nav_menu', 'schedule_cleanup_after_menu_update', 10, 1);
function schedule_cleanup_after_menu_update($menu_id) {
    if (!$menu_id) { return; }
    add_action('shutdown', 'cleanup_nav_menu_item_drafts');
}
function cleanup_nav_menu_item_drafts() {
    global $wpdb;
    $orphaned_nav_menu_items = $wpdb->get_results("
        SELECT p.ID FROM {$wpdb->posts} p
        LEFT JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
        WHERE p.post_type = 'nav_menu_item' AND p.post_status = 'draft' AND tr.object_id IS NULL
    ");
    if (!empty($orphaned_nav_menu_items)) {
        foreach ($orphaned_nav_menu_items as $post) { wp_delete_post($post->ID, true); }
    }
}

// meta crud | removing meta keys
function force_update_post_meta_keys( $null, $object_id, $meta_key, $meta_value, $unique ) {
    $unwanted_meta_keys = [ '_edit_lock', '_edit_last', ];
    if ( in_array( $meta_key, $unwanted_meta_keys, true ) ) { return true; }
    return $null;
}
add_filter( 'add_post_metadata', 'force_update_post_meta_keys', 10, 5 );
add_filter( 'update_post_metadata', 'force_update_post_meta_keys', 10, 5 );
add_filter( 'delete_post_metadata', 'force_update_post_meta_keys', 10, 5 );

// Function to log cleanup progress (optional for debugging)
function log_cleanup_process($message) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log($message);
    }
}

// Schedule the cleanup event on theme activation
function schedule_daily_cleanup() {
    if (!wp_next_scheduled('daily_orphan_data_cleanup')) {
        wp_schedule_event(time(), 'daily', 'daily_orphan_data_cleanup');
    }
}
add_action('init', 'schedule_daily_cleanup');

// Function to clean orphaned data, expired transients, and spam comments
function run_orphan_data_cleanup() {
    global $wpdb;

    log_cleanup_process('Starting orphan data cleanup.');

    // Batch processing for orphan postmeta cleanup
    $batch_size = 100;
    $offset = 0;
    do {
        $posts_to_delete = $wpdb->get_col("SELECT post_id FROM {$wpdb->postmeta} WHERE post_id NOT IN (SELECT ID FROM {$wpdb->posts}) LIMIT $batch_size OFFSET $offset");
        if (!empty($posts_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($posts_to_delete), '%d'));
            $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE post_id IN ($placeholders)", $posts_to_delete);
            $offset += $batch_size;
            log_cleanup_process('Deleted orphan postmeta in batch.');
        }
    } while (!empty($posts_to_delete));

    // Orphan commentmeta cleanup
    $batch_size = 100;
    $offset = 0;
    do {
        $comments_to_delete = $wpdb->get_col("SELECT comment_id FROM {$wpdb->commentmeta} WHERE comment_id NOT IN (SELECT comment_ID FROM {$wpdb->comments}) LIMIT $batch_size OFFSET $offset");
        if (!empty($comments_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($comments_to_delete), '%d'));
            $wpdb->query("DELETE FROM {$wpdb->commentmeta} WHERE comment_id IN ($placeholders)", $comments_to_delete);
            $offset += $batch_size;
            log_cleanup_process('Deleted orphan commentmeta in batch.');
        }
    } while (!empty($comments_to_delete));

    // Orphan usermeta cleanup
    $batch_size = 100;
    $offset = 0;
    do {
        $users_to_delete = $wpdb->get_col("SELECT user_id FROM {$wpdb->usermeta} WHERE user_id NOT IN (SELECT ID FROM {$wpdb->users}) LIMIT $batch_size OFFSET $offset");
        if (!empty($users_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($users_to_delete), '%d'));
            $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE user_id IN ($placeholders)", $users_to_delete);
            $offset += $batch_size;
            log_cleanup_process('Deleted orphan usermeta in batch.');
        }
    } while (!empty($users_to_delete));

    // Orphan termmeta cleanup
    $batch_size = 100;
    $offset = 0;
    do {
        $terms_to_delete = $wpdb->get_col("SELECT term_id FROM {$wpdb->termmeta} WHERE term_id NOT IN (SELECT term_id FROM {$wpdb->terms}) LIMIT $batch_size OFFSET $offset");
        if (!empty($terms_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($terms_to_delete), '%d'));
            $wpdb->query("DELETE FROM {$wpdb->termmeta} WHERE term_id IN ($placeholders)", $terms_to_delete);
            $offset += $batch_size;
            log_cleanup_process('Deleted orphan termmeta in batch.');
        }
    } while (!empty($terms_to_delete));

    // Orphan term relationships cleanup
    $wpdb->query("DELETE FROM {$wpdb->term_relationships} WHERE object_id NOT IN (SELECT ID FROM {$wpdb->posts})");

    // Remove expired transients
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_%' AND option_value < UNIX_TIMESTAMP()");

    // Remove all transients
    $transient_options = $wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_%' OR option_name LIKE '\_site_transient\_%'");
    if (!empty($transient_options)) {
        foreach ($transient_options as $option_name) {
            if (strpos($option_name, '_site_transient_') !== false) {
                delete_site_transient(str_replace('_site_transient_', '', $option_name));
            } else {
                delete_transient(str_replace('_transient_', '', $option_name));
            }
        }
    }

    // Remove transients marked for autoload
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE autoload = 'yes' AND option_name LIKE '_transient_%'");

    // Remove spam comments
    $spam_comments = $wpdb->get_col("SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved = 'spam'");
    if (!empty($spam_comments)) {
        foreach ($spam_comments as $comment_id) {
            wp_delete_comment((int) $comment_id, true);
        }
    }

    // Remove trashed comments
    $trashed_comments = $wpdb->get_col("SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved IN ('trash', 'post-trashed')");
    if (!empty($trashed_comments)) {
        foreach ($trashed_comments as $comment_id) {
            wp_delete_comment((int) $comment_id, true);
        }
    }

    // Remove orphaned _oembed_* postmeta (where post_id = 0)
    $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE post_id = 0 AND meta_key LIKE '_oembed_%'");

    // Define tables to optimize dynamically using the WordPress prefix
    $tables = [
        $wpdb->posts,
        $wpdb->postmeta,
        $wpdb->comments,
        $wpdb->commentmeta,
        $wpdb->users,
        $wpdb->usermeta,
        $wpdb->terms,
        $wpdb->termmeta,
        $wpdb->term_relationships,
        $wpdb->options
    ];

    // Exclude very large plugin tables like WooCommerce dynamically
    $excluded_tables = [
        $wpdb->prefix . 'woocommerce_order_items',
        $wpdb->prefix . 'woocommerce_order_itemmeta'
    ];

    foreach ($tables as $table) {
        if (!in_array($table, $excluded_tables)) {
            // Check table fragmentation before optimizing
            $analyze = $wpdb->get_results("ANALYZE TABLE $table");
            if (!empty($analyze) && strpos($analyze[0]->Msg_text, 'Table is already up to date') === false) {
                $wpdb->query("OPTIMIZE TABLE $table");
                log_cleanup_process("Optimized table: $table.");
            }
        }
    }

    // Log last cleanup time (optional)
    update_option('last_orphan_cleanup', current_time('mysql'));

    log_cleanup_process('Orphan data cleanup completed.');
}
add_action('daily_orphan_data_cleanup', 'run_orphan_data_cleanup');

// Unschedule event on theme deactivation
function unschedule_daily_cleanup() {
    $timestamp = wp_next_scheduled('daily_orphan_data_cleanup');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'daily_orphan_data_cleanup');
    }
}
add_action('switch_theme', 'unschedule_daily_cleanup');









