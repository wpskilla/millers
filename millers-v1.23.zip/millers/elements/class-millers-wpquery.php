<?php
if (!defined('ABSPATH')) exit;

class Millers_Wp_Query_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'millers_wp_query';
    }

    public function get_title() {
        return __('Millers Wp Query', 'millers-elementor-widget');
    }

    public function get_icon() {
        return 'eicon-post-list';
    }

    public function get_categories() {
        return ['millers-widgets'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section('content_section', [
            'label' => __('Query Settings', 'millers-elementor-widget'),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('post_type', [
            'label'   => __('Post Type', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'post'  => 'Post',
            ],
            'default' => 'post',
        ]);

        $this->add_control('posts_per_page', [
            'label'   => __('Number of Posts', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::NUMBER,
            'default' => 15,
        ]);

        $this->add_control('order', [
            'label'   => __('Order', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'ASC'  => 'Ascending',
                'DESC' => 'Descending',
            ],
            'default' => 'DESC',
        ]);

        $this->add_control('orderby', [
            'label'   => __('Order By', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'date'   => 'Date',
                'title'  => 'Title',
                'rand'   => 'Random',
                'comment_count' => 'Popular',
            ],
            'default' => 'date',
        ]);

        $this->add_control('style', [
            'label'   => __('Select Style', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'style-1' => 'Style 1',
                'style-2' => 'Style 2',
            ],
            'default' => 'style-1',
        ]);

        // Heading Tag Selection
        $this->add_control('post_title_tag', [
            'label'   => __('Post Title Heading Tag', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'h1' => 'H1',
                'h2' => 'H2',
                'h3' => 'H3',
                'h4' => 'H4',
                'h5' => 'H5',
                'h6' => 'H6',
            ],
            'default' => 'h2',
        ]);

        // New Toggle for Post Description
        $this->add_control('show_description', [
            'label'   => __('Show Description', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __('Show', 'millers-elementor-widget'),
            'label_off' => __('Hide', 'millers-elementor-widget'),
            'return_value' => 'yes',
            'default' => 'yes',
        ]);

        // New Toggle for Author Meta
        $this->add_control('show_author_meta', [
            'label'   => __('Show Author Meta', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __('Show', 'millers-elementor-widget'),
            'label_off' => __('Hide', 'millers-elementor-widget'),
            'return_value' => 'yes',
            'default' => 'yes',
        ]);

        // New Toggle for Term Meta
        $this->add_control('show_term_meta', [
            'label'   => __('Show Term Meta', 'millers-elementor-widget'),
            'type'    => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __('Show', 'millers-elementor-widget'),
            'label_off' => __('Hide', 'millers-elementor-widget'),
            'return_value' => 'yes',
            'default' => 'yes',
        ]);

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Style Settings', 'millers-elementor-widget'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'style2_article_padding',
            [
                'label' => __('Article Padding', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors' => [
                    '{{WRAPPER}} .post-grid.millerquery-style2 article' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Post Top Flex Gap
        $this->add_responsive_control(
            'post_top_flex_gap',
            [
                'label' => __('Post Columns Gap', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => ['px' => ['min' => 0, 'max' => 50]],
                'default' => ['size' => 10, 'unit' => 'px'],
                'selectors' => ['{{WRAPPER}} .post-top-flex' => 'gap: {{SIZE}}{{UNIT}};'],
            ]
        );

        // Post Title Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'post_title_typography',
                'label' => __('Post Title Typography', 'millers-elementor-widget'),
                'selector' => '{{WRAPPER}} .post-title',
            ]
        );

        // Post Title Margin
        $this->add_responsive_control(
            'post_title_margin',
            [
                'label' => __('Post Title Margin', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => ['{{WRAPPER}} .post-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        // Post Thumbnail Styling
        $this->add_control(
            'post_thumbnail_heading',
            [
                'label' => __('Post Thumbnail', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        // Border Control
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'thumbnail_border',
                'label' => __('Border', 'millers-elementor-widget'),
                'selector' => '{{WRAPPER}} .post-thumbnail',
            ]
        );

        // Border Radius Control
        $this->add_control(
            'thumbnail_border_radius',
            [
                'label' => __('Border Radius', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 100],
                    '%' => ['min' => 0, 'max' => 50],
                ],
                'selectors' => [
                    '{{WRAPPER}} .post-thumbnail' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Box Shadow Control
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'thumbnail_box_shadow',
                'label' => __('Box Shadow', 'millers-elementor-widget'),
                'selector' => '{{WRAPPER}} .post-thumbnail',
            ]
        );

        // Post Content Typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'post_content_typography',
                'label' => __('Post Content Typography', 'millers-elementor-widget'),
                'selector' => '{{WRAPPER}} .post-content p',
            ]
        );

        // Post Content Margin
        $this->add_responsive_control(
            'post_content_margin',
            [
                'label' => __('Post Content Margin', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => ['{{WRAPPER}} .post-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        // List Post Meta Margin
        $this->add_responsive_control(
            'list_post_meta_margin',
            [
                'label' => __('List Post Meta Margin', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => ['{{WRAPPER}} .list-post-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        // Post Categories Gap
        $this->add_control(
            'post_categories_gap',
            [
                'label' => __('Post Categories Gap', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => ['px' => ['min' => 0, 'max' => 50]],
                'default' => ['size' => 5, 'unit' => 'px'],
                'selectors' => ['{{WRAPPER}} article.type-post .post-categories' => 'gap: {{SIZE}}{{UNIT}};'],
            ]
        );

        // Post Categories List Item Styling
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'post_categories_typography',
                'label' => __('Post Categories Typography', 'millers-elementor-widget'),
                'selector' => '{{WRAPPER}} article.type-post .post-categories li',
            ]
        );

        $this->add_responsive_control(
            'post_categories_padding',
            [
                'label' => __('Post Categories Padding', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => ['{{WRAPPER}} article.type-post .post-categories li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'post_categories_border',
                'label' => __('Post Categories Border', 'millers-elementor-widget'),
                'selector' => '{{WRAPPER}} article.type-post .post-categories li',
            ]
        );

        $this->add_control(
            'post_categories_border_radius',
            [
                'label' => __('Post Categories Border Radius', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => ['px' => ['min' => 0, 'max' => 50]],
                'selectors' => ['{{WRAPPER}} article.type-post .post-categories li' => 'border-radius: {{SIZE}}{{UNIT}};'],
            ]
        );

        $this->add_control(
            'post_categories_bg_color',
            [
                'label' => __('Post Categories Background', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} article.type-post .post-categories li' => 'background-color: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'post_categories_text_color',
            [
                'label' => __('Post Categories Text Color', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} article.type-post .post-categories li a' => 'color: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'post_categories_hover_bg_color',
            [
                'label' => __('Post Categories Hover Background', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} article.type-post .post-categories li:hover' => 'background-color: {{VALUE}};'],
            ]
        );

        $this->add_control(
            'post_categories_hover_text_color',
            [
                'label' => __('Post Categories Hover Text Color', 'millers-elementor-widget'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => ['{{WRAPPER}} article.type-post .post-categories li:hover a' => 'color: {{VALUE}};'],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $title_tag = tag_escape($settings['post_title_tag']);

        // WP_Query Arguments
        $args = [
            'post_type'      => $settings['post_type'],
            'posts_per_page' => $settings['posts_per_page'],
            'order'          => $settings['order'],
            'post_status'    => 'publish',
            'no_found_rows'  => true, // Optimization
        ];

        // Handle 'popular' orderby
        if ($settings['orderby'] === 'comment_count') {
            $args['orderby'] = 'comment_count';
        } else {
            $args['orderby'] = $settings['orderby'];
        }

        $query = new WP_Query($args);

        if ($query->have_posts()) {
            ob_start(); ?>

            <style type="text/css">
                article.type-post {max-width: 750px;margin: 2rem auto;display: flex;flex-direction: column;gap: 1rem;}article.type-post img {box-shadow: 0 0 6px 1px #0000004a;}.post-grid {display: flex;gap: 2rem;flex-wrap: wrap;justify-content: center;}.post-grid article {width: 31.5%;display: flex;flex-direction: column;gap: 10px;margin: 0;}.post-grid article .post-thumbnail {height: 260px;display: flex;align-items: stretch;justify-content: center;box-shadow: 0 0 6px 1px #00000054;margin-bottom: 8px;overflow: hidden;}.post-grid article .post-thumbnail a {display: flex;align-items: stretch;justify-content: center;width: 100%;overflow: hidden;}.post-grid article .post-thumbnail img {width: 100%;object-fit: cover;transition: all 0.3s ease-in-out;}.post-grid article .post-thumbnail:hover img {scale: 1.1;}.post-grid article .post-content p {margin: 0;display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;overflow: hidden;text-overflow: ellipsis;word-break: break-word;line-height: 1.5;max-height: calc(1.5em* 2);}.post-grid article.no-thumb .post-content p {-webkit-line-clamp: 8;max-height: calc(1.5em* 8);}.post-grid article.no-thumb {justify-content: center !important;display: flex !important;box-shadow: 0 0 6px 1px #00000054;padding: 2rem;gap: 25px;}article.type-post .list-post-meta {display: flex;flex-direction: column;gap: 10px;margin-top: 4px;}article.type-post .list-post-meta .post-meta-left {display: flex;gap: 10px;}article.type-post .list-post-meta .post-meta-left .left-meta-content {display: flex;flex-direction: column;gap: 4px;font-size: 13px;line-height: 12px;text-transform: capitalize;}article.type-post .list-post-meta .author-avatar img {width: 28px;border-radius: 50%;box-shadow: 0 0 6px 1px #0000005e;}article.type-post .post-categories {padding: 0;display: flex;flex-direction: row;flex-wrap: wrap;gap: 8px;}article.type-post .post-categories li, article.type-post .post-tags a {list-style: none;background-color: #F2F2F2;padding: 3px 10px;font-size: 12px;border-radius: 99rem;}article.type-post .post-title:hover, article.type-post a:hover {text-decoration: underline;}
                @media screen and (max-width: 1350px) {.post-grid {gap: 1rem;}.post-grid article {width: 32%;}.post-grid article .post-thumbnail {height: 220px;}}
                @media screen and (max-width: 900px) {.post-grid article {width: 48%;}.post-grid article .post-thumbnail {height: 200px;}}
                @media screen and (max-width: 550px) {.post-grid {gap: 2rem;}.post-grid article {width: 100%;}article.type-post .post-title, article.type-post h1 {font-size: 28px;line-height: 33px;}article.type-post h2 {font-size: 24px;line-height: 28px;}article.type-post h3 {font-size: 20px;line-height: 25px;}}
            </style>

            <!-- // Style 1 - Grid Layout -->
            <?php if ($settings['style'] == 'style-1') { ?>
                <div class="post-grid millerquery-style1">
                <?php while ($query->have_posts()) : $query->the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(has_post_thumbnail() ? '' : 'no-thumb'); ?>>
                        <!-- thumbnail -->
                        <?php if (has_post_thumbnail()) { ?>
                            <div class="post-thumbnail"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_post_thumbnail('medium', ['loading' => 'lazy']); ?></a></div>
                        <?php } ?>
                        <!-- title -->
                        <div class="post-header">
                            <<?php echo $title_tag; ?> class="post-title">
                                <a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title(); ?></a>
                            </<?php echo $title_tag; ?>>
                        </div>
                        <?php if ($settings['show_description'] === 'yes') { ?>
                            <!-- excerpt -->
                            <div class="post-content"><?php the_excerpt(); ?></div>
                        <?php } ?>
                        <!-- post meta -->
                        <?php if ($settings['show_author_meta'] != '' || $settings['show_term_meta'] != '') { ?>
                            <div class="list-post-meta">
                                <?php if ($settings['show_author_meta'] === 'yes') { ?>
                                <div class="post-meta-left">
                                    <div class="author-avatar">
                                        <?php echo get_avatar(get_the_author_meta('ID'), 50); ?>
                                    </div>
                                    <div class="left-meta-content">
                                        <span class="post-author">
                                            <?php _e('By', 'millers'); ?> 
                                            <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                                                <?php the_author(); ?>
                                            </a>
                                        </span> 
                                        <div class="meta-box-date"><a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php echo get_the_date('F j, Y'); ?></a></div>
                                    </div>
                                </div>
                                <?php } if ($settings['show_term_meta'] === 'yes') { ?>
                                <div class="post-meta-right"><?php the_category(); ?></div>
                                <?php } ?>
                            </div>
                        <?php } ?>
                    </article>
                <?php endwhile; ?>
                </div>
            <?php } ?>

            <!-- // Style 2 - List Layout -->
            <?php if ($settings['style'] == 'style-2') { ?>
                <style type="text/css">.post-grid.millerquery-style2 {gap: 0;justify-content: start;}.post-grid.millerquery-style2 article {width: 100%;max-width: 100%;box-shadow: unset;padding: 32px 0;border-bottom: 1px solid #F2F2F2;}.post-grid.millerquery-style2 article:first-child {padding-top: 0;}.post-grid.millerquery-style2 article:last-child {border-bottom: unset;padding-bottom: 0;}.post-grid.millerquery-style2 .post-top-flex {display: flex;gap: 3rem;align-items: stretch;}.post-grid.millerquery-style2 .ptf-left {width: 70%;display: flex;flex-direction: column;gap: 10px;justify-content: center;}.post-grid.millerquery-style2 .ptf-right {width: 30%;display: flex;align-items: center;justify-content: center;}.post-grid.millerquery-style2 .post-thumbnail {height: unset;margin: 0;}.post-grid.millerquery-style2 .post-content {max-width: 700px;}.post-grid.millerquery-style2 article.no-thumb {box-shadow: unset;padding-left: 0;padding-right: 0;}.post-grid.millerquery-style2 article.no-thumb .post-content p {-webkit-line-clamp: 2;max-height: calc(1.5em* 2);}.post-grid.millerquery-style2 article.no-thumb .ptf-left {width: 100%;}.post-grid.millerquery-style2 article.no-thumb .ptf-right {display: none;}
                    @media screen and (max-width: 550px) {.post-grid.millerquery-style2 article {padding: 25px 0;}.post-grid.millerquery-style2 .post-top-flex {gap: 2rem;flex-wrap: wrap;}.post-grid.millerquery-style2 .ptf-left {width: 100%;order: 1;}.post-grid.millerquery-style2 .ptf-right {width: 100%;}}</style>
                <div class="post-grid millerquery-style2">
                <?php while ($query->have_posts()) : $query->the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(has_post_thumbnail() ? '' : 'no-thumb'); ?>>
                        <div class="post-top-flex">
                            <div class="ptf-left">
                                <!-- title -->
                                <div class="post-header">
                                    <<?php echo $title_tag; ?> class="post-title">
                                        <a href="<?php echo esc_url(get_permalink()); ?>"><?php the_title(); ?></a>
                                    </<?php echo $title_tag; ?>>
                                </div>
                                <?php if ($settings['show_description'] === 'yes') { ?>
                                    <!-- excerpt -->
                                    <div class="post-content"><?php the_excerpt(); ?></div>
                                <?php } ?>
                                <!-- post meta -->
                                <?php if ($settings['show_author_meta'] != '' || $settings['show_term_meta'] != '') { ?>
                                    <div class="list-post-meta">
                                        <?php if ($settings['show_author_meta'] === 'yes') { ?>
                                        <div class="post-meta-left">
                                            <div class="author-avatar">
                                                <?php echo get_avatar(get_the_author_meta('ID'), 50); ?>
                                            </div>
                                            <div class="left-meta-content">
                                                <span class="post-author">
                                                    <?php _e('By', 'millers'); ?> 
                                                    <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                                                        <?php the_author(); ?>
                                                    </a>
                                                </span> 
                                                <div class="meta-box-date"><a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d')); ?>"><?php echo get_the_date('F j, Y'); ?></a></div>
                                            </div>
                                        </div>
                                        <?php } if ($settings['show_term_meta'] === 'yes') { ?>
                                        <div class="post-meta-right"><?php the_category(); ?></div>
                                        <?php } ?>
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="ptf-right">
                                <!-- thumbnail -->
                                <?php if (has_post_thumbnail()) { ?>
                                    <div class="post-thumbnail"><a href="<?php echo esc_url(get_permalink()); ?>"><?php the_post_thumbnail('medium', ['loading' => 'lazy']); ?></a></div>
                                <?php } ?>
                            </div>
                        </div>
                    </article>
                <?php endwhile; ?>
                </div>
            <?php } ?>

            <?php wp_reset_postdata();
            echo ob_get_clean();
        }
    }
}




