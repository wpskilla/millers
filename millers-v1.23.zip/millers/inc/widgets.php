<?php

function register_swiper_assets() {
    wp_register_style('millers-swiper-css', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css');
    wp_register_script('millers-swiper-js', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'register_swiper_assets');

function category_slider_shortcode() {
	// enqueue Swiper assets
	wp_enqueue_style('millers-swiper-css');
	wp_enqueue_script('millers-swiper-js');
    ob_start();
    ?>
    <div class="millers-cat-slider-wrap">
        <div class="swiper millers-cat-slider">
            <div class="swiper-wrapper">
                <?php
                $categories = get_categories(array('hide_empty' => true));
                foreach ($categories as $category) :
                ?>
                    <div class="swiper-slide">
                        <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>" class="category-link">
                            <?php echo esc_html($category->name); ?>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
            <!-- Navigation buttons -->
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            new Swiper('.millers-cat-slider', {
                slidesPerView: 'auto',
                spaceBetween: 7,
                loop: true,
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
            });
        });
    </script>
    <style>
        .millers-cat-slider-wrap {width: 100%;overflow: hidden;position: relative;padding: 10px 0;display: flex;margin-bottom: 7px;}
        .millers-cat-slider-wrap .swiper-wrapper {display: flex;align-items: center;}
        .millers-cat-slider-wrap .swiper-slide {flex-shrink: 0;width: auto;text-align: center;white-space: nowrap;background-color: #F2F2F2;padding: 4px 11px;font-size: 12px;border-radius: 99rem;border: 1px solid #191919;}
        .millers-cat-slider-wrap .swiper-slide:hover {background-color: #191919;color: white;text-decoration: unset;}
        .millers-cat-slider-wrap .swiper-slide:hover a {color: white;}
        .millers-cat-slider-wrap .swiper-button-next, .millers-cat-slider-wrap .swiper-button-prev {background-color: unset;color: black;width: 20px;height: 40px;margin-top: -20px;}
        .millers-cat-slider-wrap .swiper-button-next::after, .millers-cat-slider-wrap .swiper-button-prev::after {font-size: 18px;font-weight: bold;}
        .millers-cat-slider-wrap .swiper-button-disabled {display: none;}
        .millers-cat-slider-wrap .swiper-button-prev {background: linear-gradient(270deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.75) 25%, rgba(255, 255, 255, 0.9) 50%, rgb(255, 255, 255) 75%);padding: 0rem 25px;left: 0;}
        .millers-cat-slider-wrap .swiper-button-next {background: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.75) 25%, rgba(255, 255, 255, 0.9) 50%, rgb(255, 255, 255) 75%);padding: 0rem 25px;right: 0;}
        @media screen and (max-width: 768px) {
            .millers-cat-slider-wrap .swiper-slide {padding: 3px 7px;margin-right: 7px !important;}
            .millers-cat-slider-wrap .swiper-button-prev {padding: 0rem 15px 0 6px;}
            .millers-cat-slider-wrap .swiper-button-next {padding: 0rem 6px 0 15px;}
        }
    </style>
    <?php
    return ob_get_clean();
}
add_shortcode('category_slider', 'category_slider_shortcode');


