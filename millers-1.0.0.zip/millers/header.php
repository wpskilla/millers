<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
    <style type="text/css">
        /* Reset and general styles */:root{--primairy-color: #17938d;}body {margin: 0;padding: 0;font-family: cursive;line-height: 1.6;background-color: #f9f9f9;}body a {color: var(--primairy-color);}.container {width: 90%;max-width: 1200px;margin: 0 auto;padding: 1rem 0;}/* Header and Navigation */header {background-color: var(--primairy-color);padding: 1rem;margin-bottom: 1rem;border-radius: 5px;}header nav ul {list-style: none;margin: 0;padding: 0;display: flex;justify-content: center;gap: 1rem;}header nav ul li {display: inline;}header nav ul li a {text-decoration: none;color: #fff;font-weight: bold;padding: 0.5rem 1rem;border-radius: 5px;transition: background-color 0.3s;}header nav ul li a:hover,header nav ul li a[aria-current="page"] {background-color: #555;}/* Main Content */article {background-color: #fff;padding: 2rem;margin-bottom: 1rem;border-radius: 5px;box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);}article header h1,article header h2, article header a {color: white;}.page-header {margin-bottom: 2rem;}.page-header .page-title {color: white;margin: 0;}article h1,article h2 {color: #222;margin-bottom: 1rem;}article .post-thumbnail {text-align: center;margin-bottom: 20px;}article .post-thumbnail img {max-width: 100%;width: 100%;object-fit: cover;max-height: 550px;height: auto;border-radius: 8px;box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.06);}article p {margin-bottom: 1rem;}article .entry-content {max-width: 100%;margin: 0 auto;word-wrap: break-word;}article .entry-content img {max-width: 100%;width: 100%;object-fit: cover;max-height: 550px;height: auto;display: block;margin: 20px 0;border-radius: 8px;box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);}article .entry-content .wp-block-gallery img{margin: 0}article .entry-content iframe,article .entry-content embed,article .entry-content video {max-width: 100%;height: auto;display: block;margin: 20px 0;}article .entry-content blockquote {padding: 20px;margin: 20px 0;background-color: #f9f9f9;border-left: 4px solid #0073aa;font-style: italic;color: #555;}article .entry-content ul,article .entry-content ol {padding-left: 20px;margin: 20px 0;}footer a {color: white;}/* Footer */footer {background-color: var(--primairy-color);color: #fff;text-align: center;padding: 1rem 0;margin-top: 1rem;border-radius: 5px;}footer p {margin: 0;}/* Responsive Design */@media (max-width: 768px) {header nav ul {flex-direction: column;align-items: center;}header nav ul li {margin-bottom: 0.5rem;}}
    </style>
</head>
<body <?php body_class(); ?>>
    <div class="container">
        <header>
            <nav>
                <?php
                wp_nav_menu([
                    'theme_location' => 'primary',
                    'container' => false,
                ]);
                ?>
            </nav>
        </header>
    </div>